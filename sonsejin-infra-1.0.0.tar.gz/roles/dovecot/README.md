# dovecot

이 역할은 dovecot 서비스를 설치하고 구성합니다.

## 주요 기능
- dovecot 설치
- 서비스 활성화
- 관련 포트 방화벽 허용
